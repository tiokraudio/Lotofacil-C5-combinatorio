import React, { useState, useEffect } from "react";
import {
  Sparkles,
  Lock,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  RefreshCw,
  ArrowRight,
  ShieldCheck,
  Layers,
  Printer,
  Download,
} from "lucide-react";
import { ContestRecord } from "../c5-memory/types";
import {
  generateMemoryDraftUI,
  confirmMemoryDraftUI,
  discardMemoryDraftUI,
  getMemoryOperationalStateUI,
  getAllContestRecordsUI,
  getOfficialHistoricalCoverageUI,
  syncOfficialHistoricalDrawsUI,
  OfficialDrawsCoverageStatus,
  Draft30,
} from "../c5-memory/application/uiService";
import { Ball } from "./Ball";

interface C5MemoryViewProps {
  currentContestNumber: number;
  onContestUpdated: () => void;
  onNavigateToConference: (contestNumber: number) => void;
}

export const C5MemoryView: React.FC<C5MemoryViewProps> = ({
  currentContestNumber,
  onContestUpdated,
  onNavigateToConference,
}) => {
  const [contestNumber, setContestNumber] = useState<number>(currentContestNumber);
  const [record, setRecord] = useState<ContestRecord | null>(null);
  const [draft, setDraft] = useState<Draft30 | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isConfirming, setIsConfirming] = useState(false);
  const [copiedHash, setCopiedHash] = useState(false);
  const [copiedGames, setCopiedGames] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [historyRevision, setHistoryRevision] = useState<number>(0);
  const [coverageStatus, setCoverageStatus] = useState<OfficialDrawsCoverageStatus | null>(null);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncFeedback, setSyncFeedback] = useState<{ message: string; type: "success" | "warning" | "error" } | null>(null);

  useEffect(() => {
    setContestNumber(currentContestNumber);
  }, [currentContestNumber]);

  useEffect(() => {
    loadContestData(contestNumber);
    refreshCoverage();
  }, [contestNumber]);

  useEffect(() => {
    // Na inicialização, carrega o estado persistido imediatamente
    refreshCoverage();
    // Se online, tenta sincronização incremental automática em segundo plano
    if (typeof navigator !== "undefined" && navigator.onLine) {
      syncOfficialHistoricalDrawsUI()
        .then(() => refreshCoverage())
        .catch(() => {});
    }
  }, []);

  const refreshCoverage = async () => {
    try {
      const cov = await getOfficialHistoricalCoverageUI();
      setCoverageStatus(cov);
    } catch (e) {
      console.warn("Falha ao obter status de cobertura:", e);
    }
  };

  const handleSyncCaixa = async () => {
    setIsSyncing(true);
    setErrorMsg(null);
    setSyncFeedback(null);
    try {
      const res = await syncOfficialHistoricalDrawsUI();
      await refreshCoverage();
      if (res.syncedCount > 0) {
        setSyncFeedback({
          message: `Sincronização concluída: ${res.syncedCount} concurso(s) importado(s) (${res.syncedContests.join(", ")}). Base oficial atualizada até o concurso #${res.lastContest}.`,
          type: "success",
        });
      } else if (res.success) {
        setSyncFeedback({
          message: `Base histórica oficial já está atualizada até o concurso #${res.lastContest}.`,
          type: "success",
        });
      } else {
        setSyncFeedback({
          message: res.reason || "Modo offline: sem conexão com os servidores da Caixa. Base preservada.",
          type: "warning",
        });
      }
    } catch (e: any) {
      console.warn("Aviso na sincronização com Caixa:", e);
      setSyncFeedback({
        message: e?.message || "Erro durante sincronização com a Caixa.",
        type: "error",
      });
    } finally {
      setIsSyncing(false);
    }
  };

  const loadContestData = async (cNum: number) => {
    setErrorMsg(null);
    try {
      const allRecords = await getAllContestRecordsUI();
      const existing = allRecords.find(r => r.contestNumber === cNum);
      const state = await getMemoryOperationalStateUI(cNum);
      setHistoryRevision(state.historyRevision);
      if (state.draft && (state.draft.algorithmVersion === "C5-Memory-3.0" || "metrics" in state.draft)) {
        setDraft(state.draft as Draft30);
      } else {
        setDraft(null);
      }
      if (existing) {
        setRecord(existing);
      } else if (state.status !== "AVAILABLE" || state.draft) {
        setRecord({
          contestNumber: state.contestNumber,
          contestDate: (state as any).contestDate || "",
          status: state.status,
          algorithmVersion: state.algorithmVersion as any,
          games: state.games,
          draft: state.draft as any,
          frozenPayload: state.frozenPayload as any,
          officialResult: state.officialResult,
          gameHits: state.gameHits,
          bestHits: state.bestHits,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
      } else {
        setRecord(null);
      }
    } catch (err: any) {
      setErrorMsg("Erro ao carregar dados do concurso: " + err.message);
    }
  };

  const handleGenerate = async () => {
    setIsGenerating(true);
    setErrorMsg(null);

    try {
      const newDraft = await generateMemoryDraftUI(contestNumber);
      setDraft(newDraft);
      await loadContestData(contestNumber);
      await refreshCoverage();
      setIsGenerating(false);
      onContestUpdated();
    } catch (err: any) {
      setErrorMsg(err.message || "Erro na geração combinatória.");
      setIsGenerating(false);
    }
  };

  const handleConfirmAndFreeze = async () => {
    if (!draft || isConfirming) return;
    if (record?.status === "FROZEN" || record?.status === "COMPLETED") {
      setErrorMsg("APPLICATION_DOUBLE_CONFIRM_BLOCKED: Concurso já confirmado.");
      return;
    }

    setIsConfirming(true);
    setErrorMsg(null);
    try {
      const confirmed = await confirmMemoryDraftUI(draft.contestNumber, draft);
      setRecord(confirmed);
      setDraft(null);
      onContestUpdated();
    } catch (err: any) {
      setErrorMsg("Erro ao confirmar aposta atômica: " + err.message);
    } finally {
      setIsConfirming(false);
    }
  };

  const handleDiscardPreview = async () => {
    try {
      await discardMemoryDraftUI(contestNumber);
      setDraft(null);
      setRecord(null);
      onContestUpdated();
    } catch (err: any) {
      setErrorMsg("Erro ao descartar preview: " + err.message);
    }
  };

  const handleCopySha = (sha: string) => {
    navigator.clipboard.writeText(sha);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2000);
  };

  const handleCopyGames = () => {
    if (!record?.games) return;
    const text = record.games
      .map((g, i) => `Jogo ${i + 1}: ${g.map(n => String(n).padStart(2, "0")).join(" ")}`)
      .join("\n");
    navigator.clipboard.writeText(text);
    setCopiedGames(true);
    setTimeout(() => setCopiedGames(false), 2000);
  };

  const handlePrintGames = () => {
    window.print();
  };

  const handleExportTxt = () => {
    const targetGames = record?.games || draft?.games;
    if (!targetGames || targetGames.length === 0) return;
    const cNum = record?.contestNumber || draft?.contestNumber || contestNumber;
    let txt = `LOTOFÁCIL - APOSTAS C5-MEMORY\n`;
    txt += `Concurso: #${cNum}\n`;
    txt += `Data: ${new Date().toLocaleDateString("pt-BR")}\n`;
    txt += `Algoritmo: C5-Memory 3.0 (Critério MAX-LEXIMIN & Distância de Johnson)\n`;
    if (record?.frozenPayload) {
      txt += `Hash SHA-256: ${record.frozenPayload.sha256}\n`;
      txt += `Revisão Histórica: #${record.frozenPayload.historyRevision}\n`;
    }
    txt += `---------------------------------------------------\n`;
    targetGames.forEach((g, i) => {
      txt += `Jogo ${i + 1}: ${g.map(n => String(n).padStart(2, "0")).join(" ")}\n`;
    });
    txt += `---------------------------------------------------\n`;
    const blob = new Blob([txt], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `lotofacil-c5-concurso-${cNum}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleAdvanceToNextContest = () => {
    setContestNumber(prev => prev + 1);
  };

  const currentStatus = record?.status || (draft ? "PREVIEW" : "AVAILABLE");

  return (
    <div className="space-y-8 max-w-4xl mx-auto pb-16">
      {/* Topo do Gerador */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs uppercase font-mono tracking-wider text-emerald-400 font-semibold">
                Ciclo Diário Oficial
              </span>
              <span className="text-slate-600">•</span>
              <span className="text-xs text-slate-400">AVAILABLE → PREVIEW → FROZEN → COMPLETED</span>
            </div>
            <h1 className="text-2xl font-bold text-slate-100">
              Gerador C5-Memory 3.0
            </h1>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Concurso:</span>
            <input
              type="number"
              value={contestNumber}
              onChange={e => setContestNumber(Math.max(1, Number(e.target.value)))}
              disabled={isGenerating || currentStatus === "PREVIEW"}
              className="bg-slate-950 border border-slate-700 text-slate-100 font-mono font-bold text-base rounded-lg px-3 py-1.5 w-28 text-center focus:ring-1 focus:ring-emerald-500 outline-none"
            />
          </div>
        </div>

        {/* Stepper do Ciclo */}
        <div className="mt-6 pt-5 border-t border-slate-800 grid grid-cols-4 gap-2 text-center text-xs">
          {[
            { id: "AVAILABLE", label: "1. Disponível" },
            { id: "PREVIEW", label: "2. Prévia C5" },
            { id: "FROZEN", label: "3. Congelado" },
            { id: "COMPLETED", label: "4. Apurado" },
          ].map((st, idx) => {
            const isCurrent = currentStatus === st.id;
            const isDone =
              (st.id === "AVAILABLE" && currentStatus !== "AVAILABLE") ||
              (st.id === "PREVIEW" && (currentStatus === "FROZEN" || currentStatus === "COMPLETED")) ||
              (st.id === "FROZEN" && currentStatus === "COMPLETED");

            return (
              <div
                key={st.id}
                className={`py-2 px-1 rounded-lg border font-medium ${
                  isCurrent
                    ? "bg-emerald-500/10 border-emerald-500/40 text-emerald-300 font-bold"
                    : isDone
                    ? "bg-slate-800/40 border-slate-700/60 text-slate-400"
                    : "bg-slate-950/40 border-slate-900 text-slate-600"
                }`}
              >
                {st.label}
              </div>
            );
          })}
        </div>
      </div>

      {errorMsg && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm flex items-center gap-3">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Estado AVAILABLE: Botão de Geração */}
      {currentStatus === "AVAILABLE" && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center space-y-6 shadow-xl">
          <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
            <Sparkles className="w-8 h-8" />
          </div>

          <div className="max-w-md mx-auto space-y-2">
            <h3 className="text-xl font-bold text-slate-100">
              Pronto para Gerar o Concurso {contestNumber}
            </h3>
            <p className="text-xs text-slate-400">
              Serão avaliados K=500 candidatos pelo critério MAX-LEXIMIN em relação aos {historyRevision * 5} jogos registrados na memória histórica canônica (Revisão {historyRevision}).
            </p>
          </div>

          {/* Status de Sincronização da Base Oficial Caixa */}
          {coverageStatus && (
            <div className="max-w-md mx-auto p-3.5 rounded-xl border text-xs flex items-center justify-between gap-3 bg-slate-950/70 border-slate-800">
              <div className="flex items-center gap-2.5 text-left">
                {coverageStatus.isCompleteHistoricalCoverage ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                )}
                <div>
                  <span className="font-semibold text-slate-200 block">
                    {coverageStatus.isCompleteHistoricalCoverage
                      ? "Base Oficial Caixa Sincronizada"
                      : coverageStatus.updateVerificationStatus === "UNVERIFIED_OFFLINE"
                      ? "Modo Offline / Sem Conexão Caixa"
                      : "Base Oficial Desatualizada"}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {coverageStatus.totalLoaded} concursos carregados (1 ao {coverageStatus.lastContest || coverageStatus.totalLoaded}) • Exclusão histórica ativa
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={handleSyncCaixa}
                disabled={isSyncing || isGenerating}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-[11px] flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50 shrink-0"
                title="Sincronizar resultados com a API oficial da Caixa"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? "animate-spin text-emerald-400" : ""}`} />
                <span>{isSyncing ? "Sincronizando..." : "Sincronizar"}</span>
              </button>
            </div>
          )}

          {syncFeedback && (
            <div
              className={`max-w-md mx-auto p-3 rounded-xl border text-xs flex items-center gap-2.5 text-left ${
                syncFeedback.type === "success"
                  ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
                  : syncFeedback.type === "warning"
                  ? "bg-amber-500/10 border-amber-500/30 text-amber-300"
                  : "bg-rose-500/10 border-rose-500/30 text-rose-300"
              }`}
            >
              {syncFeedback.type === "success" ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              <span>{syncFeedback.message}</span>
            </div>
          )}

          <div>
            <button
              id="btn-generate-c5"
              data-testid="btn-generate"
              onClick={handleGenerate}
              disabled={isGenerating}
              className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-base transition-all shadow-lg shadow-emerald-600/30 cursor-pointer disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  <span>Sincronizando com a Caixa e avaliando K=500 candidatos...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  <span>Gerar C5 (Memory 3.0)</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Estado PREVIEW: Visualização e Confirmação */}
      {currentStatus === "PREVIEW" && draft && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-amber-500/30 rounded-2xl p-6 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
              <div>
                <span className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
                  Prévia Gerada — Aguardando Confirmação
                </span>
                <h3 className="text-xl font-bold text-slate-100 mt-0.5">
                  Concurso {draft.contestNumber}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  id="btn-discard-preview"
                  data-testid="btn-discard"
                  onClick={handleDiscardPreview}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs cursor-pointer transition-colors"
                >
                  Descartar
                </button>
                <button
                  id="btn-confirm-freeze"
                  data-testid="btn-confirm"
                  onClick={handleConfirmAndFreeze}
                  disabled={isConfirming}
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer transition-all disabled:opacity-50"
                >
                  <Lock className="w-4 h-4" />
                  <span>Confirmar e Congelar Aposta (SHA-256)</span>
                </button>
              </div>
            </div>

            {/* Metadados do Draft C5-Memory 3.0 */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/70 p-3 rounded-xl border border-slate-800 text-xs">
              <div>
                <span className="text-slate-500 block">Índice no Pool:</span>
                <span className="font-mono text-slate-200 font-bold">#{draft.poolIndex} de K=500</span>
              </div>
              <div>
                <span className="text-slate-500 block">Perfil Leximin (Distâncias):</span>
                <span className="font-mono text-emerald-400 font-bold">
                  [{draft.leximinProfile.join(", ")}]
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Comparação Score:</span>
                <span className="font-mono text-slate-200">
                  {draft.scoringHistorySource === "OFFICIAL_CONTEST_DRAWS"
                    ? `Sorteios Oficiais (${draft.scoringHistorySize ?? draft.officialCoverage?.totalLoaded ?? 0} conc.)`
                    : `Histórico H (Rev ${draft.historyRevision})`}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Filtro Anti-Duplicatas:</span>
                <span className="font-mono text-emerald-400 font-semibold">
                  {draft.metrics?.rejectedDuplicateOfficialCount ?? 0} oficiais • {draft.metrics?.rejectedDuplicateGeneratedCount ?? 0} em H
                </span>
              </div>
            </div>

            {/* Banner de Cobertura da Base Oficial */}
            {draft.isHistoricalExclusionComplete ? (
              <div className="mt-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs px-3.5 py-2.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>
                    <strong>Base Histórica Completa:</strong> {draft.officialCoverage?.totalLoaded ?? draft.scoringHistorySize ?? 0} concursos (concurso {draft.officialCoverage?.firstContest ?? 1} ao {draft.officialCoverage?.lastContest ?? 0}) • Exclusão histórica 100% comprovada.
                  </span>
                </div>
                <span className="font-mono text-[11px] text-slate-400 shrink-0">
                  Caixa Econômica Federal
                </span>
              </div>
            ) : (
              <div className="mt-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs px-3.5 py-2.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>
                    <strong>Aviso de Cobertura Parcial:</strong> {draft.officialCoverage?.limitationNotice || "Base oficial incompleta. Exclusão histórica completa não pode ser garantida."}
                  </span>
                </div>
                <span className="font-mono text-[11px] text-amber-400 font-bold shrink-0">
                  COBERTURA PARCIAL
                </span>
              </div>
            )}
          </div>

          {/* Os 5 Jogos Gerados */}
          <div className="space-y-3">
            {draft.games.map((game, idx) => (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md"
              >
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono font-bold text-xs flex items-center justify-center">
                    J{idx + 1}
                  </span>
                  <span className="text-xs font-medium text-slate-400">Jogo Oficial C5</span>
                </div>

                <div className="flex flex-wrap gap-1.5 justify-end">
                  {game.map(num => (
                    <Ball key={num} number={num} size="sm" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Estado FROZEN: Aposta Congelada com Hash SHA-256 */}
      {currentStatus === "FROZEN" && record?.frozenPayload && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs uppercase font-mono text-emerald-400 font-bold">
                    Aposta Congelada Criptograficamente
                  </span>
                  <h3 className="text-xl font-bold text-slate-100">
                    Concurso {record.contestNumber}
                  </h3>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  id="btn-copy-frozen-games"
                  onClick={handleCopyGames}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs border border-slate-700 cursor-pointer transition-all"
                  title="Copiar os 5 jogos congelados"
                >
                  {copiedGames ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedGames ? "Copiado!" : "Copiar Jogos"}</span>
                </button>

                <button
                  id="btn-print-frozen-games"
                  onClick={handlePrintGames}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs border border-slate-700 cursor-pointer transition-all"
                  title="Imprimir os 5 jogos congelados"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Imprimir</span>
                </button>

                <button
                  id="btn-export-frozen-txt"
                  onClick={handleExportTxt}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs border border-slate-700 cursor-pointer transition-all"
                  title="Baixar arquivo TXT com as apostas formatadas"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Baixar TXT</span>
                </button>

                <button
                  onClick={() => onNavigateToConference(record.contestNumber)}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs shadow-lg shadow-indigo-600/20 cursor-pointer transition-all"
                >
                  <span>Conferir Resultado Oficial</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Hash SHA-256 com Botão de Cópia */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center gap-1.5 font-medium">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  Hash de Congelamento SHA-256 (Imutável):
                </span>
                <span className="text-[11px] text-slate-500">
                  {new Date(record.frozenPayload.frozenAt).toLocaleString("pt-BR")}
                </span>
              </div>

              <div className="flex items-center gap-2 bg-slate-900 px-3 py-2 rounded-lg border border-slate-800">
                <span className="font-mono text-xs text-emerald-400 select-all break-all flex-1">
                  {record.frozenPayload.sha256}
                </span>
                <button
                  onClick={() => handleCopySha(record.frozenPayload!.sha256)}
                  className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                  title="Copiar hash"
                >
                  {copiedHash ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>

          {/* Jogos Congelados */}
          <div className="space-y-3">
            {record.games.map((game, idx) => (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md"
              >
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono font-bold text-xs flex items-center justify-center">
                    J{idx + 1}
                  </span>
                  <span className="text-xs font-medium text-slate-400">Aposta Registrada</span>
                </div>

                <div className="flex flex-wrap gap-1.5 justify-end">
                  {game.map(num => (
                    <Ball key={num} number={num} size="sm" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Estado COMPLETED: Apurado com Opção de Avançar para N+1 */}
      {currentStatus === "COMPLETED" && record && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs uppercase font-mono text-purple-400 font-bold">
                Concurso Apurado e Concluído
              </span>
              <h3 className="text-xl font-bold text-slate-100">
                Concurso {record.contestNumber}
              </h3>
            </div>

            <button
              id="btn-next-cycle-from-completed"
              onClick={handleAdvanceToNextContest}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/20 cursor-pointer transition-all"
            >
              <span>Avançar para Concurso {record.contestNumber + 1}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Resultado e Acertos */}
          {record.officialResult && (
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <span className="text-xs text-slate-400 block">Resultado Oficial Sorteado:</span>
              <div className="flex flex-wrap gap-1.5">
                {record.officialResult.map(n => (
                  <Ball key={n} number={n} isOfficial size="sm" />
                ))}
              </div>
            </div>
          )}

          {/* Jogos com Acertos Destacados */}
          <div className="space-y-3">
            {record.games.map((game, idx) => {
              const hits = record.gameHits ? record.gameHits[idx] : 0;
              const isBest = hits === record.bestHits;
              return (
                <div
                  key={idx}
                  className={`border rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md ${
                    isBest
                      ? "bg-slate-900/90 border-emerald-500/40"
                      : "bg-slate-900 border-slate-800"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-8 h-8 rounded-lg bg-slate-800 text-slate-200 font-mono font-bold text-xs flex items-center justify-center">
                      J{idx + 1}
                    </span>
                    <span className={`text-xs font-bold font-mono px-2 py-0.5 rounded ${
                      isBest ? "bg-emerald-500/20 text-emerald-300" : "bg-slate-800 text-slate-400"
                    }`}>
                      {hits} acertos
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-1.5 justify-end">
                    {game.map(num => {
                      const isHit = record.officialResult?.includes(num);
                      return <Ball key={num} number={num} isHit={isHit} size="sm" />;
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
